package edu.udel.dianali.gameframework;

/**
 * Created by jatlas on 4/11/17.
 */

public interface Model {
    public void update(float time);
}
