
public class Objects {

}
